package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.Operacion;
import org.mongodb.model.Prestamo;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;
import java.lang.String;


@ApplicationScoped
public class PrestamoService {
    @Inject
    ReactiveMongoClient mongoClient;

    public Uni<List<Prestamo>> list() {
        return getCollection().find()
                .map(doc -> {

                    Prestamo prestamo = new Prestamo();
                    prestamo.setNumeroPrestamo(doc.getString("NumeroPrestamo"));
                    prestamo.setMontoPagado( Integer.parseInt(doc.getString("MontoPagado") )  );
                    prestamo.setMontoPendiente(Integer.parseInt(doc.getString("MontoPendiente")));
                    prestamo.setMontoTotal(Integer.parseInt(doc.getString("MontoTotal")));
                    prestamo.setDeudaAtrasada(Integer.parseInt(doc.getString("DeudaAtrasada")));
                    prestamo.setCuotasPagadas(Integer.parseInt(doc.getString("CuotasPagadas")));
                    prestamo.setCuotasPendientes(Integer.parseInt(doc.getString("CuotasPendientes")));
                    prestamo.setNumeroCuenta(doc.getString("NumeroCuenta"));
                  //  prestamo.setOperacionPrestamo(doc.getObject("OPERACION"));

                    return prestamo;
                }).collect().asList();
    }

    public Uni<Void> add(Prestamo prestamo) {


        Document document = new Document()
                .append("NumeroPrestamo", prestamo.getNumeroPrestamo())
                .append("MontoPagado", prestamo.getMontoPagado())
                .append("MontoPendiente",prestamo.getMontoPendiente())
                .append("MontoTotal",prestamo.getMontoTotal())
                .append("DeudaAtrasada",prestamo.getDeudaAtrasada())
                .append("CuotasPagadas",prestamo.getCuotasPagadas())
                .append("CuotasPendientes",prestamo.getCuotasPendientes())
                .append("NumeroCuenta",prestamo.getNumeroCuenta())
                .append("OPERACION",prestamo.getOperacion());


        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }

    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("PRESTAMOS");
    }
}
