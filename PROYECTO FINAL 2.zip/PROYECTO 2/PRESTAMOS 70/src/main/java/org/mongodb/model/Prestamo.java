package org.mongodb.model;

import java.util.Objects;
public class Prestamo {


    public String  NumeroPrestamo;
    public Integer MontoPagado;
    public Integer MontoPendiente;
    public Integer MontoTotal;
    public Integer DeudaAtrasada;
    public Integer CuotasPagadas;
    public Integer CuotasPendientes;
    public String  NumeroCuenta;

    public Operacion operacion;

    public String getNumeroPrestamo() {
        return NumeroPrestamo;
    }

    public void setNumeroPrestamo(String numeroPrestamo) {
        NumeroPrestamo = numeroPrestamo;
    }

    public Integer getMontoPagado() {
        return MontoPagado;
    }

    public void setMontoPagado(Integer montoPagado) {
        MontoPagado = montoPagado;
    }

    public Integer getMontoPendiente() {
        return MontoPendiente;
    }

    public void setMontoPendiente(Integer montoPendiente) {
        MontoPendiente = montoPendiente;
    }

    public Integer getMontoTotal() {
        return MontoTotal;
    }

    public void setMontoTotal(Integer montoTotal) {
        MontoTotal = montoTotal;
    }

    public Integer getDeudaAtrasada() {
        return DeudaAtrasada;
    }

    public void setDeudaAtrasada(Integer deudaAtrasada) {
        DeudaAtrasada = deudaAtrasada;
    }

    public Integer getCuotasPagadas() {
        return CuotasPagadas;
    }

    public void setCuotasPagadas(Integer cuotasPagadas) {
        CuotasPagadas = cuotasPagadas;
    }

    public Integer getCuotasPendientes() {
        return CuotasPendientes;
    }

    public  String getNumeroCuenta(){
		     return NumeroCuenta; }

    public  void  setNumeroCuenta(String numeroCuenta){
		          NumeroCuenta = numeroCuenta;
			        }



    public void setCuotasPendientes(Integer cuotasPendientes) {
        CuotasPendientes = cuotasPendientes;
    }

    public Operacion getOperacion() {
        return operacion;
    }

    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }

    public Prestamo() {
         }



}
