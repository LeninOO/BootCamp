package org.mongodb.resource;

import io.smallrye.mutiny.Uni;


import org.mongodb.model.Prestamo;

import org.mongodb.service.PrestamoService;

import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/prestamo")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PrestamoResource {

    @Inject
    PrestamoService prestamoService;

    @GET
    public Uni<List<Prestamo>> list() {
        return prestamoService.list();
    }

    @POST
    public Uni<Response> add(Prestamo prestamo) {
        return prestamoService.add(prestamo)
                .onItem().transform(id -> URI.create("/prestamo/" + id))
                .onItem().transform(uri -> Response.created(uri).build());
    }
}
