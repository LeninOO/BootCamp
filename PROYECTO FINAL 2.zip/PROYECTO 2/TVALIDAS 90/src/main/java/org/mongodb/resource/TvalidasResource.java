package org.mongodb.resource;

import io.smallrye.mutiny.Uni;
import org.mongodb.model.Tvalidas;
import org.mongodb.service.TvalidasService;

import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/tvalidas")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TvalidasResource {

    @Inject
    TvalidasService tvalidasService;

    @GET
    public Uni<List<Tvalidas>> list() {
        return tvalidasService.list();
    }

    @POST
    public Uni<Response> add(Tvalidas tvalidas) {
        return tvalidasService.add(tvalidas)
                .onItem().transform(id -> URI.create("/tvalidas/" + id))
                .onItem().transform(uri -> Response.created(uri).build());
    }
}
