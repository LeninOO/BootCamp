package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.Operacion;
import org.mongodb.model.Tvalidas;
import java.lang.String;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;


@ApplicationScoped
public class TvalidasService {
    @Inject
    ReactiveMongoClient mongoClient;

    public Uni<List<Tvalidas>> list() {
        return getCollection().find()
                .map(doc -> {
                    Tvalidas tvalidas = new Tvalidas();

                    tvalidas.setNumeroCuentaAsociada(doc.getString("NumeroCuentaAsociada"));
                    tvalidas.setTitular(doc.getString("Titular"));
                    tvalidas.setTipoDocumento(doc.getString("TipoDocumento"));
                    tvalidas.setNumeroDocumento(doc.getString("NumeroDocumento"));
                    tvalidas.setNumeroTarjeta(doc.getString("NumeroTarjeta"));
                   // tvalidas.setOperacion(doc.getObject(operacion));

                    return tvalidas;
                }).collect().asList();
    }




    public Uni<Void> add(Tvalidas tvalidas) {
        Document document = new Document("name","TVALIDAS")
                .append("NumeroCuentaAsociada", tvalidas.getNumeroCuentaAsociada())
                .append("Titular", tvalidas.getTitular())
                .append("TipoDocumento",tvalidas.getTipoDocumento())
                .append("NumeroDocumento",tvalidas.getNumeroDocumento())
                .append("NumeroTarjeta",tvalidas.getNumeroTarjeta())
                .append("OPERACION",tvalidas.getOperacion());

        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }

    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("TVALIDAS");
    }
}
