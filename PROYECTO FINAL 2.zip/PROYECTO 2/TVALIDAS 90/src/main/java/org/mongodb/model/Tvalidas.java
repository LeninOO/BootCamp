package org.mongodb.model;

import java.util.Objects;
public class Tvalidas{

    public Operacion operacionTvalidas;
    public String  NumeroCuentaAsociada;
    public String  Titular ;
    public String  TipoDocumento;
    public String  NumeroDocumento;
    public String  NumeroTarjeta;
    public Operacion operacion;



    public String getNumeroCuentaAsociada() {
        return NumeroCuentaAsociada;
    }

    public void setNumeroCuentaAsociada(String numeroCuentaAsociada) {
        NumeroCuentaAsociada = numeroCuentaAsociada;
    }

    public String getTitular() {
        return Titular;
    }

    public void setTitular(String titular) {
        Titular = titular;
    }

    public String getTipoDocumento() {
        return TipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        TipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return NumeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        NumeroDocumento = numeroDocumento;
    }

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }
    public Operacion getOperacion() {
	        return operacion;
	    }

	public void setOperacion(Operacion operacion) {
	        this.operacion = operacion;
    }





    public Tvalidas() {
    }




}
