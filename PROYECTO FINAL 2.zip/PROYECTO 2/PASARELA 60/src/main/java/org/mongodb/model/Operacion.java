package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class Operacion {
    private String Descripcion;
    private String CodOperacion;
    private LocalDateTime Fecha ;
    private Integer Monto ;

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getCodOperacion() {
        return CodOperacion;
    }

    public void setCodOperacion(String codOperacion) {
        CodOperacion = codOperacion;
    }

    public LocalDateTime getFecha() {
        return Fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        Fecha = fecha;
    }

    public Integer getMonto() {
        return Monto;
    }

    public void setMonto(Integer monto) {
        Monto = monto;
    }

    public Operacion() {
    }



    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Operacion)) {
            return false;
        }

        Operacion other = (Operacion) obj;

        return Objects.equals(other);
    }


}
