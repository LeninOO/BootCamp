package org.mongodb.model;

import java.util.Objects;
public class Llave {
    public String  NumeroTarjeta;
    public Integer Pin;

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public Integer getPin() {
        return Pin;
    }

    public void setPin(Integer pin) {
        Pin = pin;
    }

    public Llave() {
                   }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Llave)) {
            return false;
        }

        Llave other = (Llave) obj;

        return Objects.equals(other);
    }

}
