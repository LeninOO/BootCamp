package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class Operacion {
    private String Descripcion;
    private String CodOperacion;
    private String Fecha ;
    private Integer Monto ;

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getCodOperacion() {
        return CodOperacion;
    }

    public void setCodOperacion(String codOperacion) {
        CodOperacion = codOperacion;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public Integer getMonto() {
        return Monto;
    }

    public void setMonto(Integer monto) {
        Monto = monto;
    }

    public Operacion() {
    }






}
