package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.Cuenta;
import org.mongodb.model.Operacion;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;
import java.lang.String;



@ApplicationScoped
public class CuentaService {
    @Inject
    ReactiveMongoClient mongoClient;
    Operacion operacion ;
    public Uni<List<Cuenta>> list() {
        return getCollection().find()
                .map(doc -> {
                    Cuenta cuenta = new Cuenta();
                    cuenta.setNumeroCuenta(doc.getString("NumeroCuenta"));
                    cuenta.setTitular(doc.getString("Titular"));
                    cuenta.setTipoDocumento(doc.getString("TipoDocumento"));
                    cuenta.setNumeroDocumento(doc.getString("NumeroDocumento"));
                    cuenta.setSaldoCuenta( Integer.parseInt( doc.getString("SaldoCuenta" ) ));
                    cuenta.setTarjetaAsociada1(doc.getString("TarjetaAsociada1"));
                    cuenta.setTarjetaAsociada2(doc.getString("TarjetaAsociada2"));
                    cuenta.setSede(doc.getString("Sede"));
                    cuenta.setOperacion(doc.getObject(operacion));

                    return cuenta;
                }).collect().asList();
    }



    public Uni<Void> add(Cuenta cuenta) {
        Document document = new Document()
                .append("NumeroCuenta", cuenta.getNumeroCuenta())
                .append("Titular", cuenta.getTitular())
                .append("TipoDocumento",cuenta.getTipoDocumento())
                .append("NumeroDocumento",cuenta.getNumeroDocumento())
                .append("SaldoCuenta",cuenta.getSaldoCuenta())
                .append("TarjetaAsociada1",cuenta.getTarjetaAsociada1())
                .append("TarjetaAsociada2 ",cuenta.getTarjetaAsociada2())
                .append("Sede", cuenta.getSede())
                .append("Operacion",cuenta.getOperacion()  );


        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }





    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("CUENTA");
    }
}
