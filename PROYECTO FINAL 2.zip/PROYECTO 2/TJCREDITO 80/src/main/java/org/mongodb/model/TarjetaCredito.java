package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class TarjetaCredito {


    public String  NumeroTarjeta;
    public String  NumeroCuentaAsociada;
    public Integer LineaCredito;
    public Integer LineaDisponible;
    public Integer CreditoUtilizado;
    public String FechaFacturacion;
    public Operacion operacion;

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public String getNumeroCuentaAsociada() {
        return NumeroCuentaAsociada;
    }

    public void setNumeroCuentaAsociada(String numeroCuentaAsociada) {
        NumeroCuentaAsociada = numeroCuentaAsociada;
    }

    public Integer getLineaCredito() {
        return LineaCredito;
    }

    public void setLineaCredito(Integer lineaCredito) {
        LineaCredito = lineaCredito;
    }

    public Integer getLineaDisponible() {
        return LineaDisponible;
    }

    public void setLineaDisponible(Integer lineaDisponible) {
        LineaDisponible = lineaDisponible;
    }

    public Integer getCreditoUtilizado() {
        return CreditoUtilizado;
    }

    public void setCreditoUtilizado(Integer creditoUtilizado) {
        CreditoUtilizado = creditoUtilizado;
    }

    public String getFechaFacturacion() {
        return FechaFacturacion;
    }

    public void setFechaFacturacion(String fechaFacturacion) {
        FechaFacturacion = fechaFacturacion;
    }

    public Operacion getOperacion() {
        return operacion;
    }


    public void setOperacion(Operacion operacion) {
        this.operacion = operacion;
    }




}
