package org.mongodb.resource;

import io.smallrye.mutiny.Uni;

import org.mongodb.model.TarjetaCredito;
import org.mongodb.service.TarjetaCreditoService;

import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/tarjetacredito")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class TarjetaCreditoResource {

    @Inject
    TarjetaCreditoService tarjetaCreditoService;

    @GET
    public Uni<List<TarjetaCredito>> list() {
        return tarjetaCreditoService.list();
    }

    @POST
    public Uni<Response> add(TarjetaCredito tarjetaCredito) {
        return tarjetaCreditoService.add(tarjetaCredito)
                .onItem().transform(id -> URI.create("/tarjetacredito/" + id))
                .onItem().transform(uri -> Response.created(uri).build());
    }
}
