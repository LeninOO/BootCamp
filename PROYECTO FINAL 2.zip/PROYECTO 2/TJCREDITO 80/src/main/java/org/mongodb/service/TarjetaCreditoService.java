package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.TarjetaCredito;
import org.mongodb.model.Operacion;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.LocalDateTime;
import java.util.List;
import java.lang.String;

@ApplicationScoped
public class TarjetaCreditoService {
    @Inject
    ReactiveMongoClient mongoClient;

    public Uni<List<TarjetaCredito>> list() {
        return getCollection().find()
                .map(doc -> {
                    TarjetaCredito tarjetaCredito = new TarjetaCredito();

                    tarjetaCredito.setNumeroTarjeta(doc.getString("NumeroTarjeta"));
                    tarjetaCredito.setNumeroCuentaAsociada(doc.getString("NumeroCuentaAsociada"));
                    tarjetaCredito.setLineaCredito( Integer.parseInt(doc.getString("LineaCredito")));
                    tarjetaCredito.setLineaDisponible(Integer.parseInt(doc.getString("LineaDisponible")));
                    tarjetaCredito.setCreditoUtilizado(Integer.parseInt(doc.getString("CreditoUtilizado")));
                    tarjetaCredito.setFechaFacturacion(doc.getString("FechaFacturacion"));
                  // tarjetaCredito.setOperacionTarjetaCredito(doc.getObject(operacionTarjetaCredito));


                    return tarjetaCredito;
                }).collect().asList();
    }




    public Uni<Void> add(TarjetaCredito tarjetaCredito) {
        Document document = new Document("name","TCREDITO")
                .append("NumeroTarjeta", tarjetaCredito.getNumeroTarjeta())
                .append("NumeroCuentaAsociada", tarjetaCredito.getNumeroCuentaAsociada())
                .append("LineaCredito",tarjetaCredito.getLineaCredito())
                .append("LineaDisponible",tarjetaCredito.getLineaDisponible())
                .append("CreditoUtilizado",tarjetaCredito.getCreditoUtilizado())
                .append("FechaFacturacion",tarjetaCredito.getFechaFacturacion())
                .append("OPERACION",tarjetaCredito.getOperacion());

        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }

    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("TCREDITO");
    }
}
