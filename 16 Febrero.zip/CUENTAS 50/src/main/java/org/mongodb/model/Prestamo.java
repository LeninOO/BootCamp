package org.mongodb.model;

import java.util.Objects;
public class Prestamo {


    public String  NumeroPrestamo;
    public Float MontoPagado;
    public Float MontoPendiente;
    public Float MontoTotal;
    public Float DeudaAtrasada;
    public Integer CuotasPagadas;
    public Integer CuotasPendientes;
    private Operacion operacionPrestamo;

    public String getNumeroPrestamo() {
        return NumeroPrestamo;
    }

    public void setNumeroPrestamo(String numeroPrestamo) {
        NumeroPrestamo = numeroPrestamo;
    }

    public Float getMontoPagado() {
        return MontoPagado;
    }

    public void setMontoPagado(Float montoPagado) {
        MontoPagado = montoPagado;
    }

    public Float getMontoPendiente() {
        return MontoPendiente;
    }

    public void setMontoPendiente(Float montoPendiente) {
        MontoPendiente = montoPendiente;
    }

    public Float getMontoTotal() {
        return MontoTotal;
    }

    public void setMontoTotal(Float montoTotal) {
        MontoTotal = montoTotal;
    }

    public Float getDeudaAtrasada() {
        return DeudaAtrasada;
    }

    public void setDeudaAtrasada(Float deudaAtrasada) {
        DeudaAtrasada = deudaAtrasada;
    }

    public Integer getCuotasPagadas() {
        return CuotasPagadas;
    }

    public void setCuotasPagadas(Integer cuotasPagadas) {
        CuotasPagadas = cuotasPagadas;
    }

    public Integer getCuotasPendientes() {
        return CuotasPendientes;
    }

    public void setCuotasPendientes(Integer cuotasPendientes) {
        CuotasPendientes = cuotasPendientes;
    }

    public Operacion getOperacionPrestamo() {
        return operacionPrestamo;
    }

    public void setOperacionPrestamo(Operacion operacionPrestamo) {
        this.operacionPrestamo = operacionPrestamo;
    }

    public Prestamo() {
         }




    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Prestamo)) {
            return false;
        }

        Prestamo other = (Prestamo) obj;

        return Objects.equals(other);
    }

}
