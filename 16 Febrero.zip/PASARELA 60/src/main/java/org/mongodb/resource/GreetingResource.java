package org.acme;

import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import org.acme.Category;
import org.acme.Tag;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import java.util.ArrayList;
import java.util.List;

@Path("/pet")
public class GreetingResource {

    @RestClient
    PetApi petApi;

    @GET
    @Path("/findByStatus")
    @Produces(MediaType.APPLICATION_JSON)
    public Multi<PetResponse> findByStatus(@QueryParam("status") String status) {
       /* return petApi.findByStatus(status).map(pets -> {

            return new PetResponse();
        });*/

       //Reactivo
        return petApi.findByStatus(status).onItem().<Pet>disjoint().map(pet -> {
            PetResponse petResponse = new PetResponse();
            petResponse.setId(pet.getId());
            petResponse.setCategory(pet.getCategory());
            petResponse.setName(pet.getName());
            petResponse.setPhotoUrls(pet.getPhotoUrls());
            petResponse.setTags(pet.getTags());
            petResponse.setStatus(pet.getStatus());
            return petResponse;
        });




//No reactivo
       /* List<PetResponse> petResponses=new ArrayList<>();
        List<Pet> byStatus = petApi.findByStatus(status);
        byStatus.forEach(pet -> {
            PetResponse petResponse = new PetResponse();
            petResponse.setId(pet.getId());
            petResponse.setCategory(pet.getCategory());
            petResponse.setName(pet.getName());
            petResponse.setPhotoUrls(pet.getPhotoUrls());
            petResponse.setTags(pet.getTags());
            petResponse.setStatus(pet.getStatus());
            petResponses.add(petResponse);
        });
        return petResponses;*/
    }
}
