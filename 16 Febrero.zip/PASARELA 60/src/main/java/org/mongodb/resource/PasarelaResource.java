package org.mongodb.resource;

import io.smallrye.mutiny.Uni;
import org.mongodb.model.Fruit;
import org.mongodb.service.FruitService;

import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;


@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PasarelaResource {

    @Inject
    FruitService fruitService;


    @Path("/registra")
    @POST
    public Uni<Response> validar(Cerradura cerradura){
                          buscaCuenta( );
                          asignarCuenta();
                          guardarTvalidas();
              return      Response pin ;
                                          }


    @Path("/cambiarPin")
    @POST
	public Uni<Response> cambiar(Llave llave) {
	                      validarllave(llave);
	                      pedirnueva("ingrese nueva  llave");
	                      enviarTjvalidas(LLave  nueva );
	                      confirmarCambio();

                                              }
     @Path("/saldos")
	 @POST
	 public Uni<Response> reporte(LLave llave) {
	                           validallave(llave);
	                           pedirSaldoTarjeta();
	                           pedirSaldoCuenta();
	                           pedirSaldoPrestamo();
	                           responder();


                                              }
     @Path("/tarjetaCredito")
	 @POST
	 public Uni<Response> add(Fruit fruit) {
	        return fruitService.add(fruit)
	                .onItem().transform(id -> URI.create("/tarjetaCredito/" + id))
	                .onItem().transform(uri -> Response.created(uri).build());
                                              }

     @Path("/prestamos")
	 @POST
	 public Uni<Response> add(Fruit fruit) {
	         return fruitService.add(fruit)
	                 .onItem().transform(id -> URI.create("/prestamos/" + id))
	                 .onItem().transform(uri -> Response.created(uri).build());
                                          }

     @Path("/cuenta")
	 @POST
	 public Uni<Response> add(Fruit fruit) {
	         return fruitService.add(fruit)
	                 .onItem().transform(id -> URI.create("/cuenta/" + id))
	                 .onItem().transform(uri -> Response.created(uri).build());
                                          }


}
