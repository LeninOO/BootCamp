package nttdata.bootcamp.quarkus.entity;


import io.quarkus.mongodb.panache.common.MongoEntity;
import lombok.*;
import org.bson.types.ObjectId;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@MongoEntity(collection="coin")
public class Coin {

 //   private Object _id;

    private ObjectId id;

    private String idClient;
    private String phone;
    private String idDebitCard;
    
    private String compradorPhone;
    private String documento;
    private String numerodocumento;
    private String cantidad;
    private String pagar ;

    private String validationCode;
   
}
