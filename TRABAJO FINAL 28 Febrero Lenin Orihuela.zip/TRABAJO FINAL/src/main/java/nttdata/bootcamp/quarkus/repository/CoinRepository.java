package nttdata.bootcamp.quarkus.repository;

import io.quarkus.mongodb.panache.reactive.ReactivePanacheMongoRepository;
import io.smallrye.mutiny.Multi;
import jakarta.enterprise.context.ApplicationScoped;
import nttdata.bootcamp.quarkus.entity.Wallet;
import nttdata.bootcamp.quarkus.entity.Coin;
import org.bson.Document;

@ApplicationScoped
public class CoinRepository implements ReactivePanacheMongoRepository<Coin> {


    public Multi<Coin> getAll() {
        return streamAll();
    }



}
