package nttdata.bootcamp.quarkus.dto.request;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WalletSaveCoinDTO {

    private String compradorPhone;
    private String tipodocumento;
    private String numerodocumento;
    private String cantidad ;
    private String cardnumber; // Tarjeta del vendedor

    private String validationCodeCoin;

}
