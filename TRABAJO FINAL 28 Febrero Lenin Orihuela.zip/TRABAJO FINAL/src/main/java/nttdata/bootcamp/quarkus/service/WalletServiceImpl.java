package nttdata.bootcamp.quarkus.service;


import io.smallrye.common.annotation.Blocking;
import io.smallrye.common.annotation.NonBlocking;
import io.smallrye.mutiny.Multi;
import io.smallrye.mutiny.Uni;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import nttdata.bootcamp.quarkus.dto.request.WalletSaveCoinDTO;
import nttdata.bootcamp.quarkus.dto.request.WalletSaveDTO;
import nttdata.bootcamp.quarkus.dto.response.WalletSaveResponseDTO;
import nttdata.bootcamp.quarkus.entity.Coin;
import nttdata.bootcamp.quarkus.entity.History;
import nttdata.bootcamp.quarkus.entity.Wallet;
import nttdata.bootcamp.quarkus.entity.api.Client;
import nttdata.bootcamp.quarkus.entity.redis.TicketCoin;
import nttdata.bootcamp.quarkus.entity.redis.WalletRedis;
import nttdata.bootcamp.quarkus.repository.WalletRepository;
import nttdata.bootcamp.quarkus.repository.redis.WalletRedisRepository;
import nttdata.bootcamp.quarkus.service.api.RedisApi;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import nttdata.bootcamp.quarkus.repository.redis.TicketCoinRepository;
//import org.mongodb.model.Operacion;
import nttdata.bootcamp.quarkus.dto.InterfazCuentaRestClient;
import nttdata.bootcamp.quarkus.entity.Operacion;
import nttdata.bootcamp.quarkus.repository.CoinRepository;
import nttdata.bootcamp.quarkus.dto.response.WalletSaveResponseCoinDTO;

import jakarta.ws.rs.NotFoundException;
import java.time.Instant;
import java.util.*;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.Random;

@ApplicationScoped
public class WalletServiceImpl implements  WalletService{


    HistoryService historyService;

    @Inject
    WalletRepository walletRepository;

    @Inject
    CoinRepository coinRepository;

    @Inject
    WalletRedisRepository walletRedisRepository;

    @Inject
    TicketCoinRepository   ticketCoinRepository;


  //  @RestClient
  //  RedisApi redisApi;

    @RestClient
    InterfazCuentaRestClient interfazCuentaRestClient;


    private String generateApprovalCode(){
        byte[] array = new byte[8];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));
        return generatedString;
    }

    private BigDecimal convert( BigDecimal cantidad){
        BigDecimal factor = (1.5);
        BigDecimal resultado = cantidad.multiply(factor);

        return resultado;
    }
    @Override
    public Uni<WalletSaveResponseDTO> saveWallet(WalletSaveDTO walletSaveDTO, Client client) {
        Wallet wallet = new Wallet();

        wallet.setPhone(client.getCellPhone());
        wallet.setPassword(walletSaveDTO.getPassword());
        wallet.setIdClient(walletSaveDTO.getClientId());
        wallet.setValidationCode(walletSaveDTO.getValidationCode());
        wallet.setIdDebitCard(walletSaveDTO.getDebitCardId());
        wallet.setStatus("I");
     //   System.out.println("ANTES DE PERSISTIR EN BASE DE DATOS ..!!! ");

        return walletRepository.persist(wallet).flatMap(wallet1 -> {
            WalletSaveResponseDTO walletSaveResponseDTO = new WalletSaveResponseDTO();

            walletSaveResponseDTO.setIdWallet(wallet1.getId().toString());
            String approvalCode = this.generateApprovalCode();
            walletSaveResponseDTO.setApprovalCode(approvalCode);

            WalletRedis walletRedis = new WalletRedis();
            walletRedis.setIdWallet(walletSaveResponseDTO.getIdWallet());
            walletRedis.setExpirationDate(new Date());
            walletRedis.setApprovalCode(walletSaveResponseDTO.getApprovalCode());

            //redisApi.add(walletRedis);

            /*Save Cache Redis*/
          //ssf  this.registerRedisWallet(wallet1,approvalCode);
            /*-----------------*/

            return Uni.createFrom().item(walletSaveResponseDTO);
        });


    }

    @Override
    public Uni<WalletSaveResponseCoinDTO> saveCoin(WalletSaveCoinDTO walletSaveCoinDTO, Client client) {
        Coin coin = new Coin();

        coin.setCompradorPhone(walletSaveCoinDTO.getCellPhone());
        coin.setDocumento(walletSaveCoinDTO.getTipodocumento());
        coin.setNumerodocumento(walletSaveCoinDTO.getNumerodocumento());
        coin.setValidationCode(walletSaveCoinDTO.getValidationCodeCoin());
        coin.setCantidad(walletSaveCoinDTO.getCantidad());
        String tempo2 = walletSaveCoinDTO.getCantidad();
        BigDecimal tempo3 = BigDecimal(tempo2);
        BigDecimal opera1 = convert(tempo3);
        String opera2 = opera1.toString();
        coin.setPagar(opera2);
     //   System.out.println("ANTES DE PERSISTIR EN BASE DE DATOS ..!!! ");

        return CoinRepository.persist(coin).flatMap(coin1 -> {
            WalletSaveResponseCoinDTO walletSaveResponseCoinDTO = new WalletSaveResponseCoinDTO();

            walletSaveResponseCoinDTO.setIdCoin(coin1.getId().toString());
            String approvalCodeCoin = this.generateApprovalCode();
            walletSaveResponseCoinDTO.setApprovalCode(approvalCodeCoin);

            TicketCoin ticketCoin = new TicketCoin();
            ticketCoin.setIdCoin(walletSaveResponseCoinDTO.getIdCoin());
            ticketCoin.setApprovalCodeCoin(walletSaveResponseCoinDTO.getApprovalCodeCoin());

            //redisApi.add(walletRedis);

            /*Save Cache Redis*/
          //ssf  this.registerRedisWallet(wallet1,approvalCode);
            /*-----------------*/

            return Uni.createFrom().item(walletSaveResponseCoinDTO);
        });


    }



    public void registerRedisWallet(Wallet wallet ,String approvalCode){
        WalletRedis walletRedis = new WalletRedis();
        walletRedis.setIdWallet(wallet.getId().toString());
        walletRedis.setExpirationDate(new Date());
        walletRedis.setApprovalCode(approvalCode);
        walletRedisRepository.save(wallet.getId().toString(),walletRedis);
    }

    public void registerTicketCoin(Coin coin ,String approvalCodeCoin){
        TicketCoin ticketCoin = new TicketCoin();
        ticketCoin.setIdCoin(coin.getId().toString());
        ticketCoin.setApprovalCodeCoin(approvalCodeCoin);

        ticketCoinRepository.save(coin.getId().toString(),ticketCoin);

    }

    @Override
    public Multi<Wallet> getAll() {
        return walletRepository.getAll();
    }

    @Override
    public Uni<Void> update(String id, Wallet wallet) {
        return null;
    }

    @Override
    public Uni<Boolean> delete(String id) {
        return null;
    }

    @Override
    public Uni<Wallet> findById(String id) {
        return null;
    }

    public Operacion SendOperation(Operacion operacion, Wallet wallet,History history){

               if(interfazCuentaRestClient.Send(operacion) != operacion) {
                        // throw new NotFoundException(" The account asociated  dont ready ");
                          operacion.setCodOperacion("ERROR OPERACION");
                          Instant marca = Instant.now();
                          String  nuevo = marca.toString();
                          operacion.setFecha(nuevo);

                          history.setPhone ( wallet.getPhone());
                          history.setDate(nuevo);
                          history.setDescription("ERROR OPERACION");
                          history.setAmount(operacion.getMonto());
                          historyService.add(history);                    // Guarda el historico  para LOGS  en  Cosmo DB
                          return operacion;
                                                                     }
                    else  {

                           Instant marca = Instant.now();
                           String  nuevo = marca.toString();
                           operacion.setFecha(nuevo);
                           history.setPhone ( wallet.getPhone());
                           history.setDate(nuevo);
                           history.setDescription(operacion.getCodOperacion());
                           history.setAmount(operacion.getMonto());
                           historyService.add(history);                    // Guarda el historico  para LOGS  en  Cosmo DB
                           return operacion;

                          }


   }


}
