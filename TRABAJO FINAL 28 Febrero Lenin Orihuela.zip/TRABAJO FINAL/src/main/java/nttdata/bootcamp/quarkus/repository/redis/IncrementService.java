package nttdata.bootcamp.quarkus.repository.redis;

import io.quarkus.redis.datasource.ReactiveRedisDataSource;
import io.quarkus.redis.datasource.RedisDataSource;
import io.quarkus.redis.datasource.keys.ReactiveKeyCommands;
import io.quarkus.redis.datasource.string.StringCommands;
import io.smallrye.mutiny.Uni;
import jakarta.ejb.Singleton;

import java.util.List;

//@Singleton
public class IncrementService {

    /*
    private ReactiveKeyCommands<String> keys;
    private StringCommands<String, Integer> counter;

    public IncrementService(RedisDataSource redisDS, ReactiveRedisDataSource reactiveRedisDS) {
        keys = reactiveRedisDS.key();
        counter = redisDS.string(Integer.class);
    }


    Uni<Void> del(String key) {
        return keys.del(key)
                .replaceWithVoid();

    }

    int get(String key) {
        return counter.get(key);
    }

    void set(String key, int value) {
        counter.set(key, value);
    }

    void increment(String key, int incrementBy) {
        counter.incrby(key, incrementBy);
    }

    public Uni<List<String>> keys() {
        return keys
                .keys("*");
    }
    */

}

