package nttdata.bootcamp.quarkus.entity;

import java.time.LocalDateTime;
import java.util.Objects;
public class Operacion {

   private String NumeroTarjeta;
    private String CodOperacion;
    private String Fecha ;
    private String Monto ;

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public String getCodOperacion() {
        return CodOperacion;
    }

    public void setCodOperacion(String codOperacion) {
        CodOperacion = codOperacion;
    }


    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getMonto() {
        return Monto;
    }

    public void setMonto(String monto) {
        Monto = monto;
    }

    public Operacion(String numeroTarjeta, String codOperacion,String fecha,String monto)
     {
       this.NumeroTarjeta = numeroTarjeta ;
       this.CodOperacion= codOperacion;
       this.Fecha   = fecha;
       this.Monto   = monto;
     }

    public Operacion() {

    }






}
