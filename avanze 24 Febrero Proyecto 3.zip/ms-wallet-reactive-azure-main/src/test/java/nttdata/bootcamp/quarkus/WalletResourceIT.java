package nttdata.bootcamp.quarkus;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class WalletResourceIT extends WalletResourceTest {
    // Execute the same tests but in packaged mode.
}
