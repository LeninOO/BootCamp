package org.mongodb.service;


import io.quarkus.mongodb.reactive.ReactiveMongoClient;
import io.quarkus.mongodb.reactive.ReactiveMongoCollection;
import io.smallrye.mutiny.Uni;
import org.bson.Document;
import org.mongodb.model.Fruit;
import org.mongodb.model.Prestamo;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.util.List;


@ApplicationScoped
public class PrestamoService {
    @Inject
    ReactiveMongoClient mongoClient;

    public Uni<List<Prestamo>> list() {
        return getCollection().find()
                .map(doc -> {

                    Prestamo prestamo = new Prestamo();
                    prestamo.setNumeroPrestamo(doc.getString("NumeroPrestamo"));
                    prestamo.setMontoPagado( Integer.parseInt(doc.getString("MontoPagado") )  );
                    prestamo.setMontoPendiente(Integer.parseInt(doc.getString("MontoPendiente")));
                    prestamo.setMontoTotal(Integer.parseInt(doc.getString("MontoTotal")));
                    prestamo.setDeudaAtrasada(Integer.parseInt(doc.getString("DeudaAtrasada")));
                    prestamo.setCuotasPagadas(Integer.parseInt(doc.getString("CuotasPagadas")));
                    prestamo.setCuotasPendientes(Integer.parseInt(doc.getString("CuotasPendientes")));
                  //  prestamo.setOperacionPrestamo(doc.getObject("OPERACION"));

                    return prestamo;
                }).collect().asList();
    }

    public Uni<Void> add(Prestamo prestamo) {


        Document document = new Document("name","PRESTAMO")
                .append("NumeroPrestamo", prestamo.getNumeroPrestamo())
                .append("MontoPagado", prestamo.getMontoPagado())
                .append("MontoPendiente",prestamo.getMontoPendiente())
                .append("MontoTotal",prestamo.getMontoTotal())
                .append("DeudaAtrasada",prestamo.getDeudaAtrasada())
                .append("CuotasPagadas",prestamo.getCuotasPagadas())
                .append("CuotasPendientes",prestamo.getCuotasPendientes())
                .append("OPERACION",prestamo.getOperacionPrestamo());


        return getCollection().insertOne(document)
                .onItem().ignore().andContinueWithNull();
    }

    private ReactiveMongoCollection<Document> getCollection() {
        return mongoClient.getDatabase("Bootcamp").getCollection("PRESTAMOS");
    }
}
