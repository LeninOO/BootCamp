package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class TarjetaCredito {


    public String  NumeroTarjeta;
    public String  NumeroCuentaAsociada;
    public Float LineaCredito;
    public Float LineaDisponible;
    public Float CreditoUtilizado;
    public LocalDateTime FechaFacturacion;
    private Operacion operacionPrestamo;

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public String getNumeroCuentaAsociada() {
        return NumeroCuentaAsociada;
    }

    public void setNumeroCuentaAsociada(String numeroCuentaAsociada) {
        NumeroCuentaAsociada = numeroCuentaAsociada;
    }

    public Float getLineaCredito() {
        return LineaCredito;
    }

    public void setLineaCredito(Float lineaCredito) {
        LineaCredito = lineaCredito;
    }

    public Float getLineaDisponible() {
        return LineaDisponible;
    }

    public void setLineaDisponible(Float lineaDisponible) {
        LineaDisponible = lineaDisponible;
    }

    public Float getCreditoUtilizado() {
        return CreditoUtilizado;
    }

    public void setCreditoUtilizado(Float creditoUtilizado) {
        CreditoUtilizado = creditoUtilizado;
    }

    public LocalDateTime getFechaFacturacion() {
        return FechaFacturacion;
    }

    public void setFechaFacturacion(LocalDateTime fechaFacturacion) {
        FechaFacturacion = fechaFacturacion;
    }

    public Operacion getOperacionPrestamo() {
        return operacionPrestamo;
    }

    public void setOperacionPrestamo(Operacion operacionPrestamo) {
        this.operacionPrestamo = operacionPrestamo;
    }

    public TarjetaCredito() {
         }




}
