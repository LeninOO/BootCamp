package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class RegistroPrestamo{


    public String  CodigoOperacion;
    public Integer CodigoHtml;
    public Boolean Estado ;
    public LocalDateTime Marca ;

    public String getCodigoOperacion() {
        return CodigoOperacion;
    }

    public void setCodigoOperacion(String codigoOperacion) {
        CodigoOperacion = codigoOperacion;
    }

    public Integer getCodigoHtml() {
        return CodigoHtml;
    }

    public void setCodigoHtml(Integer codigoHtml) {
        CodigoHtml = codigoHtml;
    }

    public Boolean getEstado() {
        return Estado;
    }

    public void setEstado(Boolean estado) {
        Estado = estado;
    }

    public LocalDateTime getMarca() {
        return Marca;
    }

    public void setMarca(LocalDateTime marca) {
        Marca = marca;
    }

    public RegistroPrestamo() {
         }





}
