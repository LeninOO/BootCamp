package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class TarjetaCredito {


    public String  NumeroTarjeta;
    public String  NumeroCuentaAsociada;
    public Integer LineaCredito;
    public Integer LineaDisponible;
    public Integer CreditoUtilizado;
    public LocalDateTime FechaFacturacion;
    private Operacion operacionTarjetaCredito;

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public String getNumeroCuentaAsociada() {
        return NumeroCuentaAsociada;
    }

    public void setNumeroCuentaAsociada(String numeroCuentaAsociada) {
        NumeroCuentaAsociada = numeroCuentaAsociada;
    }

    public Integer getLineaCredito() {
        return LineaCredito;
    }

    public void setLineaCredito(Integer lineaCredito) {
        LineaCredito = lineaCredito;
    }

    public Integer getLineaDisponible() {
        return LineaDisponible;
    }

    public void setLineaDisponible(Integer lineaDisponible) {
        LineaDisponible = lineaDisponible;
    }

    public Integer getCreditoUtilizado() {
        return CreditoUtilizado;
    }

    public void setCreditoUtilizado(Integer creditoUtilizado) {
        CreditoUtilizado = creditoUtilizado;
    }

    public LocalDateTime getFechaFacturacion() {
        return FechaFacturacion;
    }

    public void setFechaFacturacion(LocalDateTime fechaFacturacion) {
        FechaFacturacion = fechaFacturacion;
    }

    public Operacion getOperacionTarjetaCredito() {
        return operacionTarjetaCredito;
    }


    public void setOperacionTarjetaCredito(Operacion operacionTarjetaCredito) {
        this.operacionTarjetaCredito = operacionTarjetaCredito;
    }




}
