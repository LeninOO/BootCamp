package org.mongodb.model;

import java.time.LocalDateTime;
import java.util.Objects;
public class AuditoriaCuenta{


    public String  CodigoOperacion;
    public Integer CodigoHtml;
    public String Titular ;
    public String NumeroTarjeta;
    public String NumeroCuenta;
    public String NumeroPrestamo;
    public String NumeroTarjetaCredito;
    public LocalDateTime Momento ;

    public String getCodigoOperacion() {
        return CodigoOperacion;
    }

    public void setCodigoOperacion(String codigoOperacion) {
        CodigoOperacion = codigoOperacion;
    }

    public Integer getCodigoHtml() {
        return CodigoHtml;
    }

    public void setCodigoHtml(Integer codigoHtml) {
        CodigoHtml = codigoHtml;
    }

    public String getTitular() {
        return Titular;
    }

    public void setTitular(String titular) {
        Titular = titular;
    }

    public String getNumeroTarjeta() {
        return NumeroTarjeta;
    }

    public void setNumeroTarjeta(String numeroTarjeta) {
        NumeroTarjeta = numeroTarjeta;
    }

    public String getNumeroCuenta() {
        return NumeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        NumeroCuenta = numeroCuenta;
    }

    public String getNumeroPrestamo() {
        return NumeroPrestamo;
    }

    public void setNumeroPrestamo(String numeroPrestamo) {
        NumeroPrestamo = numeroPrestamo;
    }

    public String getNumeroTarjetaCredito() {
        return NumeroTarjetaCredito;
    }

    public void setNumeroTarjetaCredito(String numeroTarjetaCredito) {
        NumeroTarjetaCredito = numeroTarjetaCredito;
    }

    public LocalDateTime getMomento() {
        return Momento;
    }

    public void setMomento(LocalDateTime momento) {
        Momento = momento;
    }

    public AuditoriaCuenta() {
         }





}
