package org.mongodb.model;

import java.util.Objects;
public class Cuenta {

    private Operacion operacionCuenta;

    public Operacion getOperacionCuenta() {
        return operacionCuenta;
    }

    public void setOperacionCuenta(Operacion operacionCuenta) {
        this.operacionCuenta = operacionCuenta;
    }

    public String  NumeroCuenta;
    public String  Titular ;
    public String  TipoDocumento;
    public String  NumeroDocumento;
    public Integer SaldoCuenta;
    public String  TarjetaAsociada1;
    public String TarjetaAsociada2;
    public String  Sede ;

    public String getNumeroCuenta() {
        return NumeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        NumeroCuenta = numeroCuenta;
    }

    public String getTitular() {
        return Titular;
    }

    public void setTitular(String titular) {
        Titular = titular;
    }

    public String getTipoDocumento() {
        return TipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        TipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return NumeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        NumeroDocumento = numeroDocumento;
    }

    public Integer getSaldoCuenta() {
        return SaldoCuenta;
    }

    public void setSaldoCuenta(Integer saldoCuenta) {
        SaldoCuenta = saldoCuenta;
    }

    public String getTarjetaAsociada1() {
        return TarjetaAsociada1;
    }

    public void setTarjetaAsociada1(String tarjetaAsociada1) {
        TarjetaAsociada1 = tarjetaAsociada1;
    }

    public String getTarjetaAsociada2() {
        return TarjetaAsociada2;
    }

    public void setTarjetaAsociada2(String tarjetaAsociada2) {
        TarjetaAsociada2 = tarjetaAsociada2;
    }

    public String getSede() {
        return Sede;
    }

    public void setSede(String sede) {
        Sede = sede;
    }

    public Cuenta() {
    }





}
