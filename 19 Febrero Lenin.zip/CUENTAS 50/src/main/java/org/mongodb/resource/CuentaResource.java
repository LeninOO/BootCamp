package org.mongodb.resource;

import io.smallrye.mutiny.Uni;
import org.mongodb.model.Cuenta;
import org.mongodb.model.Fruit;
import org.mongodb.service.CuentaService;
import org.mongodb.service.FruitService;

import javax.ws.rs.*;
import javax.inject.Inject;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

@Path("/cuenta")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CuentaResource {

    @Inject
    CuentaService cuentaService;

    @GET
    public Uni<List<Cuenta>> list() {
        return cuentaService.list();
    }

    @POST
    public Uni<Response> add(Cuenta cuenta) {
        return cuentaService.add(cuenta)
                .onItem().transform(id -> URI.create("/cuenta/" + id))
                .onItem().transform(uri -> Response.created(uri).build());
    }
}
